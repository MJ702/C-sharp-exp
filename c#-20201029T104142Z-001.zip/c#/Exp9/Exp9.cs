﻿using System;

namespace Exp9
{

    class Exp9
    {
        void swapNumber(int a, int b)
        {
            Console.WriteLine("\n");

            Console.WriteLine("-------Before Swap--------");
            Console.WriteLine("Int A = {0}", a);
            Console.WriteLine("Int B = {0}", b);
            int c;
            c = a;
            a = b;
            b = c;
            Console.WriteLine("-------After Swap--------");
            Console.WriteLine("Int A = {0}", a);
            Console.WriteLine("Int B = {0}", b);
        }

        void swapNumber(float a, float b)
        {
            Console.WriteLine("-------Before Swap--------");
            Console.WriteLine("Float A = {0}", a);
            Console.WriteLine("Float B = {0}", b);
            float c;
            c = a;
            a = b;
            b = c;
            Console.WriteLine("-------After Swap--------");
            Console.WriteLine("Float A = {0}", a);
            Console.WriteLine("Float B = {0}", b);
        }
        static void Main(string[] args)
        {
            Exp9 obj = new Exp9();

            obj.swapNumber(5, 10);
            Console.WriteLine("\n");
            obj.swapNumber(5.5f, 10.10f);

        }
    }
}