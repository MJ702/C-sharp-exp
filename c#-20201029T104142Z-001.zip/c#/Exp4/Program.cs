﻿using System;

namespace Exp4
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = { 2, 4, 3, 5, 7 };
            int[] b = { 9, 4, 5, 4, 3 };
            int[] result = new int[a.Length];
            int i;

            Console.Write("First Array is : ");

            foreach (int value in a)
            {
                Console.Write(value);
            }

            Console.WriteLine();


            Console.Write("Second Array is : ");

            foreach (int value in b)
            {
                Console.Write(value);
            }

            Console.WriteLine();



            for (i = 0; i < a.Length; i++)
            {
                result[i] = a[i] * b[i];
            }

            Console.Write("Multiplication is : ");


            foreach (int value in result)
            {
                Console.Write("{0} " , value);
            }
            Console.WriteLine();

        }
    }
}
