﻿using System;
using System.IO;
using System.Text;

namespace Console_I_O
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.Green;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.SetBufferSize(800, 100);
            Console.BufferHeight = 100;
            Console.BufferWidth = 200;

            TextReader tr = Console.In;
            TextWriter tout = Console.Out;
            tout.WriteLine("enter your name");
            string name = tr.ReadLine();
            tout.WriteLine("your are {0}", name);



            TextReader tIn = Console.In;
            TextWriter tOut = Console.Out;


            tOut.WriteLine("enter your Last Name: ");
            String name1 = tIn.ReadLine();
            Console.Error.WriteLine("Error: {0}", name);
            Console.Error.WriteLine();

            tOut.WriteLine("your Last Name is: {0}", name1);


            Console.Title = "c# programing";


            Console.WriteLine("Changed Title: {0}",
                                   Console.Title);
            Console.WriteLine("WindowHeight: {0}",
                                Console.WindowHeight);
            Console.WriteLine("WindowWidth: {0}",
                                Console.WindowWidth);

            Console.WriteLine("WindowLeft: {0}",
                                    Console.WindowLeft);

            Console.WriteLine("WindowTop: {0}",
                                Console.WindowTop);
            Console.WriteLine("Largest Window Height: {0}",
                          Console.LargestWindowHeight);
            Console.WriteLine("Largest Window Width: {0}",
                          Console.LargestWindowWidth);
        }
    }

}
