﻿using System;

namespace Exp5
{
    class Program
    {
        static void Main(string[] args)
        {
            String s;
            int a, b, c;

            void findSmallest(int a, int b, int c)
            {
                if (a < b && a < c)
                {
                    Console.WriteLine("{0} is Smallest ", a);
                }
                else if (b < c && b < a)
                {
                    Console.WriteLine("{0} is Smallest ", b);
                }
                else if (c < a && c < b)
                {
                    Console.WriteLine("{0} is Smallest ", c);
                }

            }

            void findLargest(int a, int b, int c)
            {
                if (a > b && a > c)
                {
                    Console.WriteLine("{0} is Largest ", a);
                }
                else if (b > a && b > c)
                {
                    Console.WriteLine("{0} is Largest ", b);
                }
                else if (c > b && c > a)
                {
                    Console.WriteLine("{0} is Largest ", c);
                }

            }

            Console.WriteLine("Enter First Number : ");
            s = Console.ReadLine();
            a = Convert.ToInt16(s);

            Console.WriteLine("Enter Second Number : ");
            s = Console.ReadLine();
            b = Convert.ToInt16(s);

            Console.WriteLine("Enter Third Number : ");
            s = Console.ReadLine();
            c = Convert.ToInt16(s);

            Console.WriteLine("\n");
            findSmallest(a, b, c);
            findLargest(a, b, c);

        }
    }
}
