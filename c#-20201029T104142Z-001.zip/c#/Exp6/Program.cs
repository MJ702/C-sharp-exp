﻿using System;

namespace Exp6
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[3];
            int[] b = new int[a.Length];
            int i, j;
            String s = "";

            Console.WriteLine("Enter 3 number : ");

            for (i = 0; i < a.Length; i++)
            {
                s = Console.ReadLine();
                a[i] = Convert.ToInt16(s);
            }

            for (i = 0, j = a.Length - 1; i < a.Length; i++, j--)
            {
                b[i] = a[j];
            }

            Console.WriteLine("\n");


            foreach (int item in b)
            {
                Console.WriteLine(item);
            }

        }
    }
}