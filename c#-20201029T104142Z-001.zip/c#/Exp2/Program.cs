﻿using System;

namespace Exp2
{
    class Program
    {
        static void Main(string[] args)
        {
            String s;
            int x, y, z;

            Console.WriteLine("Enter First Number : ");
            s = Console.ReadLine();
            x = Convert.ToInt16(s);

            Console.WriteLine("Enter Second Number : ");
            s = Console.ReadLine();
            y = Convert.ToInt16(s);

            Console.WriteLine("Enter Third Number : ");
            s = Console.ReadLine();
            z = Convert.ToInt16(s);

            Console.WriteLine("(x+y)*z = {0} ", (x + y) * z);
            Console.WriteLine("(x*y)+(y*z) = {0} ", (x * y) + (y * z));

        }
    }
}
