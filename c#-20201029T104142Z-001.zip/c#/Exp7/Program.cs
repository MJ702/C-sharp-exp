﻿using System;

namespace Exp7
{
    class Program
    {
        static void Main(string[] args)
        {

            int Val = 10;
            Object Obj = Val; //Boxing
            int i = (int)Obj; //Unboxing
        }
    }
}
