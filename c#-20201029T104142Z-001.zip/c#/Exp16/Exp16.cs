﻿using System;

namespace Exp16
{

    abstract class Abc
    {
        abstract public void Display();
    }
    class Program : Abc
    {
        public override void Display()
        {
            Console.Write("This is overrided Method of Abstrect's Class.\n");
        }
        static void Main(string[] args)
        {
            Program obj = new Program();

            obj.Display();
        }
    }
}
