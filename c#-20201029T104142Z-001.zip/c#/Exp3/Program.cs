﻿using System;

namespace Exp3
{
    class Program
    {
        static void Main(string[] args)
        {

            String s;
            int temp = 0;
            String longestWord = "";

            string[] words;

            Console.WriteLine("Enter your String : ");
            s = Console.ReadLine();

            words = s.Split(" ");

            foreach (String value in words)
            {

                if (value.Length > temp)
                {
                    longestWord = value;
                    temp = longestWord.Length;
                }
            }

            Console.WriteLine("Longest word is : {0} ", longestWord);

        }
    }
}
