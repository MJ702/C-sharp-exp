﻿using System;


class Rectangle
{



    public static void findArea(float a, float b)
    {
        Console.WriteLine("Area of Rectangle is {0} .", a * b);
    }
}

namespace Exp11
{
    public delegate void DelegateForFindAren(float a, float b);
    class Program : Rectangle
    {
        static void Main(string[] args)
        {
            DelegateForFindAren delegateObj = new DelegateForFindAren(findArea);
            delegateObj.Invoke(5.5f ,5.5f);
        }
    }
}
