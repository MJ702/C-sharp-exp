﻿using System;

namespace Exp13
{
    class Program
    {
       static void Main(string[] args)
        {
            try
            {
                int i;
                Console.WriteLine("Enter a Number : ");
                i = int.Parse(Console.ReadLine());
                if (i % 2 != 0)
                {
                    throw new Exception("Number is odd");
                    
                }
                else
                {
                    throw new Exception("Number is Even");
                    
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

        }

    }
}
