﻿using System;

namespace Exp1
{
    class Program
    {
        static void Main(string[] args)
        {
            String s;
            int a, b;

            Console.WriteLine("Enter First Number : ");
            s = Console.ReadLine();
            a = Convert.ToInt16(s);

            Console.WriteLine("Enter Second Number : ");
            s = Console.ReadLine();
            b = Convert.ToInt16(s);

            Console.WriteLine("Addition is: {0}", a + b);
            Console.WriteLine("Substrection is {0}: ", a - b);
            Console.WriteLine("Multiplicaton is {0}: ", a * b);
            Console.WriteLine("Divisoion is: {0}", a / b);

        }
    }
}
