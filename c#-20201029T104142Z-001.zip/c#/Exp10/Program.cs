﻿using System;

class Student
{
    public String name;
    public int roll;
}

class Test : Student
{
    public int marks1, marks2;
}

class Total : Test
{
    public int total;
}

namespace Exp10
{
    class Program
    {

        static void Main(string[] args)
        {
            String s;
            Total t = new Total();


            Console.WriteLine("Enter Your Name : ");
            t.name = Console.ReadLine();

            Console.WriteLine("Enter Your RollNumber : ");
            s = Console.ReadLine();
            t.roll = Convert.ToInt16(s);

            Console.WriteLine("Enter Your Marks1 : ");
            s = Console.ReadLine();
            t.marks1 = Convert.ToInt16(s);

            Console.WriteLine("Enter Your Marks2 : ");
            s = Console.ReadLine();
            t.marks2 = Convert.ToInt16(s);

            t.total = t.marks1 + t.marks2;

            Console.WriteLine("Total Marks is: "+t.total);

        }
    }
}
