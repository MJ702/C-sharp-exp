﻿using System;

namespace Exp14
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter a number: ");

                var num = int.Parse(Console.ReadLine());

                Console.WriteLine("Sqaure of {0} is {1}", num, num * num);
            }
            catch
            {
                Console.WriteLine("Error Dected.");
            }
            finally
            {
                Console.WriteLine("Try with a Other number.");
            }
        }

    }
}
