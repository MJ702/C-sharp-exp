﻿using System;

namespace Exp19
{
    class Exp19
    {
        unsafe static void Main(string[] args)
        {
            int[] array  = {5,7,8};   
            fixed(int* ptr= &array[0]){
                for (int i = 0; i < array.Length; i++)
                {
                    Console.WriteLine("Adderess of {0} position is : {1}" , i , (int)(ptr + i));  
                    Console.WriteLine("Value at {0} position is : {1}",i, *(ptr + i)); 
                }
            }

        }
    }
}
