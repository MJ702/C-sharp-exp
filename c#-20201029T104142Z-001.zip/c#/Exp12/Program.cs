﻿using System;
class Rectangle
{
    public static void printDelegate()
    {
        Console.WriteLine("Method is encapsulate by delegate.");
    } 
}

namespace Exp12
{
    public delegate void DelegateForPrintMessage();
    class Program : Rectangle
    {
        static void Main(string[] args)
        {
            DelegateForPrintMessage delegateObj = new DelegateForPrintMessage(printDelegate);
            delegateObj.Invoke();
        }
    }
}
