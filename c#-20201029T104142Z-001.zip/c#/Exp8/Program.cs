﻿using System;




namespace Exp8
{

    public class Distance
    {
        float d1, d2, total;

        public Distance(float d1, float d2)
        {
            this.d1 = d1;
            this.d2 = d2;

            this.total = this.d1 + this.d2;
            Console.WriteLine("Total Distance is = " + this.total);
        }
    }   

    class Program
    {
        static void Main(string[] args)
        {
            Distance d = new Distance(5.5f, 5.5f);
        }
    }
}
